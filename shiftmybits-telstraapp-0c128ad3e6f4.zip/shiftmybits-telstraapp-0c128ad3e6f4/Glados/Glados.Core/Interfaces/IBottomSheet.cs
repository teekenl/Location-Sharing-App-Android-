﻿using Glados.Core.Models;

namespace Glados.Core.Interfaces
{
    public interface IBottomSheet
    {
        void Show(string RespondentId, string Fullname);
    }
}
