using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Glados.Core.Interfaces;

namespace Glados.Droid.Services
{
     public class LocationAddress: ILocation
    { 

        public void GetCurrentAddress()
        {
            
           
        }


        
    }
}